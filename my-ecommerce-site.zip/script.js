document.addEventListener('DOMContentLoaded', () => {
    const addToCartButton = document.querySelector('button');
    
    addToCartButton.addEventListener('click', () => {
        alert('Product added to cart!');
        // Implement cart functionality here
    });
});